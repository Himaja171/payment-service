variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "ap-south-1"
}

variable "environment" {
  description = "Deployment environment"
  type        = string
  default     = "production"
}

variable "ecr_repo_name" {
  description = "ECR repository name for payment-service"
  type        = string
  default     = "payment-service"
}

variable "eks_cluster_name" {
  description = "EKS cluster name (created in terraform-aws-infra project)"
  type        = string
  default     = "vmsigma-eks-cluster"
}

variable "alert_email" {
  description = "Email address for CloudWatch alerts"
  type        = string
  default     = "devops-team@vmsigma.com"
}
